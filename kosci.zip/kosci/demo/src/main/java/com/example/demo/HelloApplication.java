package com.example.demo;


import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import java.util.Random;

public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) {

        TextField ilosckosci = new TextField();
        ilosckosci.setPromptText("Wprowadź ilosc kosci (od 3 do 10)");
        
        Button losuj = new Button("losuj");
        Button zamknij = new Button("Zamknij");

        GridPane dane = new GridPane();
        dane.setHgap(10);
        dane.setVgap(10);
        dane.setPadding(new Insets(10));
        dane.add(new Label("Wartość bazowa:"), 0, 0);
        dane.add(ilosckosci, 1, 0);

        GridPane wynikilosowania = new GridPane();
        wynikilosowania.setPadding(new Insets(10));
        wynikilosowania.add(new Label("wyniki losowania: "),0,0);


        HBox przyciski = new HBox(40, losuj, zamknij);
        przyciski.setAlignment(Pos.CENTER);

        VBox mainBox = new VBox(10, dane,przyciski, wynikilosowania);


        losuj.setOnAction(e -> {
            wynikilosowania.getChildren().clear();
            wynikilosowania.add(new Label("wyniki losowania: "),0,0);
            wynikilosowania.add(new Label(" "),0,1);

            String text = ilosckosci.getText();
            int ilosc = Integer.parseInt(text);

            if(ilosc<3||ilosc>10){
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Błąd danych");
                alert.setHeaderText("Niepoprawny format!");
                alert.setContentText("Proszę podać  liczbę z zakresu od 3 do 10");
                alert.showAndWait();
            }
            else {
                int[] tablica = new int[ilosc];
                Random random = new Random();

                for (int i = 0; i < ilosc; i++) {
                    tablica[i] = random.nextInt(6) + 1;
                }
                for (int i = 0; i < ilosc; i++) {
                    wynikilosowania.add(new Label("  Kostka "+i+" :  "+tablica[i]),0,i+2);
                }

                int points = 0;
                int[] powtorzenia = new int[7];
                for (int i = 0; i < tablica.length; i++) {
                    powtorzenia[tablica[i]]++;
                }
                for (int i = 1; i <= 6; i++) {
                    if (powtorzenia[i] > 1) {
                        points += powtorzenia[i] * i;
                    }
                }
                wynikilosowania.add(new Label(" "),0,12);
                wynikilosowania.add(new Label("liczba uzyskanych punktów: "+" :  "+points),0,13);
            }
        });

        zamknij.setOnAction(e -> primaryStage.close());


        Scene scene = new Scene(mainBox, 400, 400);
        primaryStage.setTitle("kosci");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}